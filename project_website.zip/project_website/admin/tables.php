<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $name = $conn->real_escape_string($_POST['table_name']);
            $conn->query("INSERT INTO tables (table_name) VALUES ('$name')");
        } elseif ($_POST['action'] == 'delete') {
            $id = $_POST['table_id'];
            $conn->query("DELETE FROM tables WHERE table_id='$id'");
        } elseif ($_POST['action'] == 'toggle') {
            $id = $_POST['table_id'];
            $current_status = $_POST['current_status'];
            $new_status = ($current_status == 'available') ? 'occupied' : 'available';
            $conn->query("UPDATE tables SET status='$new_status' WHERE table_id='$id'");
        }
    }
}

$tables = $conn->query("SELECT * FROM tables");
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Table Management</h2>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">Add New Table</div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="input-group">
                        <input type="text" name="table_name" class="form-control" placeholder="Table Name (e.g. Table 10)" required>
                        <button class="btn btn-primary" type="submit">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <?php while ($row = $tables->fetch_assoc()): ?>
        <div class="col-md-3 mb-3">
            <div class="card text-center <?php echo $row['status'] == 'available' ? 'border-success' : 'border-danger'; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['table_name']; ?></h5>
                    <p class="card-text">
                        Status:
                        <span class="badge <?php echo $row['status'] == 'available' ? 'bg-success' : 'bg-danger'; ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </span>
                    </p>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="toggle">
                        <input type="hidden" name="table_id" value="<?php echo $row['table_id']; ?>">
                        <input type="hidden" name="current_status" value="<?php echo $row['status']; ?>">
                        <button type="submit" class="btn btn-sm btn-outline-secondary">Toggle Status</button>
                    </form>
                    <form method="POST" class="d-inline" onsubmit="return confirm('Delete this table?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="table_id" value="<?php echo $row['table_id']; ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php include '../includes/footer.php'; ?>