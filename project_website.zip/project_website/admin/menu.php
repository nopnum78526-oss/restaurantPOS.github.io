<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkAdmin();

$msg = '';

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $name = $conn->real_escape_string($_POST['name']);
            $category = $conn->real_escape_string($_POST['category']);
            $price = $_POST['price'];
            $status = $_POST['status'];

            // Default to URL if provided
            $image = $conn->real_escape_string($_POST['image_url']);

            // Image Upload Override
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $target_dir = "../uploads/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                $target_file = $target_dir . basename($_FILES["image"]["name"]);
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $image = basename($_FILES["image"]["name"]);
                }
            }

            $sql = "INSERT INTO menu (name, category, price, image, status) VALUES ('$name', '$category', '$price', '$image', '$status')";
            if ($conn->query($sql)) $msg = "Menu added successfully!";
            else $msg = "Error: " . $conn->error;
        } elseif ($_POST['action'] == 'edit') {
            $id = $_POST['menu_id'];
            $name = $conn->real_escape_string($_POST['name']);
            $category = $conn->real_escape_string($_POST['category']);
            $price = $_POST['price'];
            $status = $_POST['status'];

            // Start with updating basic info
            $sql = "UPDATE menu SET name='$name', category='$category', price='$price', status='$status'";

            // Check if image URL is updated
            if (!empty($_POST['image_url'])) {
                $image_url = $conn->real_escape_string($_POST['image_url']);
                $sql .= ", image='$image_url'";
            }

            // Check if file is uploaded (overrides URL)
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $target_dir = "../uploads/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                $target_file = $target_dir . basename($_FILES["image"]["name"]);
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $image = basename($_FILES["image"]["name"]);
                    $sql .= ", image='$image'";
                }
            }

            $sql .= " WHERE menu_id='$id'";

            if ($conn->query($sql)) $msg = "Menu updated successfully!";
            else $msg = "Error: " . $conn->error;
        } elseif ($_POST['action'] == 'delete') {
            $id = $_POST['menu_id'];
            $conn->query("DELETE FROM menu WHERE menu_id='$id'");
            $msg = "Menu deleted successfully!";
        }
    }
}

$menu_items = $conn->query("SELECT * FROM menu ORDER BY category, name");
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Menu Management</h2>

<?php if ($msg): ?>
    <div class="alert alert-info"><?php echo $msg; ?></div>
<?php endif; ?>

<!-- Add Menu Button -->
<button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addMenuModal">
    <i class="bi bi-plus-circle"></i> Add New Menu
</button>

<div class="table-responsive">
    <table class="table table-bordered table-hover bg-white">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $menu_items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['menu_id']; ?></td>
                    <td>
                        <?php if ($row['image'] && filter_var($row['image'], FILTER_VALIDATE_URL)): ?>
                            <img src="<?php echo $row['image']; ?>" width="50" height="50" class="object-fit-cover">
                        <?php elseif ($row['image']): ?>
                            <img src="../uploads/<?php echo $row['image']; ?>" width="50" height="50" class="object-fit-cover">
                        <?php else: ?>
                            <span class="text-muted">No Image</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $row['name']; ?></td>
                    <td><span class="badge bg-secondary"><?php echo $row['category']; ?></span></td>
                    <td>฿<?php echo number_format($row['price'], 2); ?></td>
                    <td>
                        <?php if ($row['status']): ?>
                            <span class="badge bg-success">Available</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Unavailable</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-warning"
                            data-bs-toggle="modal"
                            data-bs-target="#editMenuModal<?php echo $row['menu_id']; ?>">
                            Edit
                        </button>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="menu_id" value="<?php echo $row['menu_id']; ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editMenuModal<?php echo $row['menu_id']; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Menu</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" name="menu_id" value="<?php echo $row['menu_id']; ?>">
                                    <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo $row['name']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Category</label>
                                        <select name="category" class="form-select" required>
                                            <option value="Appetizers" <?php echo $row['category'] == 'Appetizers' ? 'selected' : ''; ?>>Appetizers</option>
                                            <option value="Main Course" <?php echo $row['category'] == 'Main Course' ? 'selected' : ''; ?>>Main Course</option>
                                            <option value="Desserts" <?php echo $row['category'] == 'Desserts' ? 'selected' : ''; ?>>Desserts</option>
                                            <option value="Drinks" <?php echo $row['category'] == 'Drinks' ? 'selected' : ''; ?>>Drinks</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Price</label>
                                        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $row['price']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Image URL (Optional)</label>
                                        <input type="text" name="image_url" class="form-control" value="<?php echo filter_var($row['image'], FILTER_VALIDATE_URL) ? $row['image'] : ''; ?>" placeholder="https://example.com/image.jpg">
                                    </div>
                                    <div class="mb-3">
                                        <label>Or Upload Image</label>
                                        <input type="file" name="image" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Status</label>
                                        <select name="status" class="form-select">
                                            <option value="1" <?php echo $row['status'] ? 'selected' : ''; ?>>Available</option>
                                            <option value="0" <?php echo !$row['status'] ? 'selected' : ''; ?>>Unavailable</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addMenuModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Category</label>
                        <select name="category" class="form-select" required>
                            <option value="Appetizers">Appetizers</option>
                            <option value="Main Course" selected>Main Course</option>
                            <option value="Desserts">Desserts</option>
                            <option value="Drinks">Drinks</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Price</label>
                        <input type="number" step="0.01" name="price" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Image URL (Optional)</label>
                        <input type="text" name="image_url" class="form-control" placeholder="https://example.com/image.jpg">
                    </div>
                    <div class="mb-3">
                        <label>Or Upload Image</label>
                        <input type="file" name="image" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Status</label>
                        <select name="status" class="form-select">
                            <option value="1">Available</option>
                            <option value="0">Unavailable</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>