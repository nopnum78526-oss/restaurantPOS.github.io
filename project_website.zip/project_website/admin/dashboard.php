<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkAdmin();

// Get Stats
$today = date('Y-m-d');
$income_query = "SELECT SUM(total_price) as total FROM orders WHERE status = 'completed' AND DATE(order_time) = '$today'";
$income_result = $conn->query($income_query);
$daily_income = $income_result->fetch_assoc()['total'] ?? 0;

$orders_query = "SELECT COUNT(*) as count FROM orders WHERE DATE(order_time) = '$today'";
$orders_result = $conn->query($orders_query);
$daily_orders = $orders_result->fetch_assoc()['count'] ?? 0;

$best_seller_query = "
    SELECT m.name, SUM(oi.qty) as total_qty 
    FROM order_items oi 
    JOIN menu m ON oi.menu_id = m.menu_id 
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.status = 'completed'
    GROUP BY oi.menu_id 
    ORDER BY total_qty DESC 
    LIMIT 5";
$best_sellers = $conn->query($best_seller_query);
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Admin Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-header">Today's Income</div>
            <div class="card-body">
                <h5 class="card-title">฿<?php echo number_format($daily_income, 2); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-header">Today's Orders</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo $daily_orders; ?> Orders</h5>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-warning mb-3">
            <div class="card-header">Best Sellers</div>
            <div class="card-body">
                <ul class="list-unstyled mb-0">
                    <?php while ($row = $best_sellers->fetch_assoc()): ?>
                        <li><?php echo $row['name']; ?> (<?php echo $row['total_qty']; ?>)</li>
                    <?php endwhile; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">Quick Actions</div>
            <div class="card-body">
                <a href="menu.php" class="btn btn-outline-primary w-100 mb-2">Manage Menu</a>
                <a href="tables.php" class="btn btn-outline-success w-100 mb-2">Manage Tables</a>
                <a href="../register.php" class="btn btn-outline-secondary w-100">Register New Staff</a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>