<?php
function checkLogin()
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['user_id'])) {
        header("Location: /login.php");
        exit();
    }
}

function checkAdmin()
{
    checkLogin();
    if ($_SESSION['role'] !== 'admin') {
        echo "Access Denied. Admin only.";
        exit();
    }
}

function checkStaff()
{
    checkLogin();
    if ($_SESSION['role'] !== 'staff' && $_SESSION['role'] !== 'admin') {
        echo "Access Denied. Staff only.";
        exit();
    }
}

function redirect($url)
{
    header("Location: $url");
    exit();
}
