<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --bg-color: #f8f9fa;
            --text-color: #212529;
            --card-bg: #ffffff;
            --navbar-bg: #ffffff;
            --border-color: #dee2e6;
            --light-bg: #f8f9fa;
        }

        [data-theme="dark"] {
            --bg-color: #212529;
            /* Dark Gray Background */
            --text-color: #ffffff;
            /* White Text */
            --card-bg: #343a40;
            /* Darker Gray for Cards */
            --navbar-bg: #343a40;
            --border-color: #495057;
            --light-bg: #343a40;
            /* Override bg-light */
        }

        body {
            font-family: 'Sarabun', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: background-color 0.3s, color 0.3s;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .navbar {
            background-color: var(--navbar-bg) !important;
        }

        .card {
            background-color: var(--card-bg);
            color: var(--text-color);
        }

        .table {
            color: var(--text-color);
        }

        .navbar-brand {
            font-weight: bold;
            color: #ff6b6b !important;
        }

        /* Dark Mode Overrides for Bootstrap Utilities */
        [data-theme="dark"] .bg-light {
            background-color: var(--light-bg) !important;
            color: var(--text-color) !important;
        }

        [data-theme="dark"] .bg-white {
            background-color: var(--card-bg) !important;
            color: var(--text-color) !important;
        }

        [data-theme="dark"] .bg-dark {
            background-color: var(--card-bg) !important;
            color: var(--text-color) !important;
            border: 1px solid var(--text-color) !important;
        }

        [data-theme="dark"] .text-dark {
            color: var(--text-color) !important;
        }

        [data-theme="dark"] .text-muted {
            color: #adb5bd !important;
        }

        [data-theme="dark"] .table {
            color: var(--text-color) !important;
            --bs-table-color: var(--text-color);
            --bs-table-bg: var(--card-bg);
            border-color: var(--border-color);
        }

        /* Footer Styles */
        footer {
            margin-top: auto;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand" href="/index.php"><i class="bi bi-shop"></i> Restaurant OS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item me-2">
                        <button class="btn btn-sm btn-outline-secondary" id="themeToggle">
                            <i class="bi bi-moon"></i>
                        </button>
                    </li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item"><a class="nav-link" href="/admin/dashboard.php">Dashboard</a></li>
                            <li class="nav-item"><a class="nav-link" href="/admin/menu.php">Menu</a></li>
                            <li class="nav-item"><a class="nav-link" href="/admin/tables.php">Tables</a></li>
                        <?php elseif ($_SESSION['role'] == 'staff'): ?>
                            <li class="nav-item"><a class="nav-link" href="/staff/dashboard.php">Orders</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link" href="/customer/index.php">Menu</a></li>
                            <li class="nav-item"><a class="nav-link" href="/customer/cart.php">Cart</a></li>
                            <li class="nav-item"><a class="nav-link" href="/customer/orders.php">My Orders</a></li>
                        <?php endif; ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                <?php echo htmlspecialchars($_SESSION['user_name']); ?> (<?php echo ucfirst($_SESSION['role']); ?>)
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="/login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="/register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <script>
        const toggleBtn = document.getElementById('themeToggle');
        const body = document.body;
        const icon = toggleBtn.querySelector('i');

        // Check local storage
        if (localStorage.getItem('theme') === 'dark') {
            body.setAttribute('data-theme', 'dark');
            icon.classList.replace('bi-moon', 'bi-sun');
            toggleBtn.classList.replace('btn-outline-secondary', 'btn-outline-light');
            document.querySelector('.navbar').classList.replace('navbar-light', 'navbar-dark');
        }

        toggleBtn.addEventListener('click', () => {
            if (body.hasAttribute('data-theme')) {
                body.removeAttribute('data-theme');
                localStorage.setItem('theme', 'light');
                icon.classList.replace('bi-sun', 'bi-moon');
                toggleBtn.classList.replace('btn-outline-light', 'btn-outline-secondary');
                document.querySelector('.navbar').classList.replace('navbar-dark', 'navbar-light');
            } else {
                body.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
                icon.classList.replace('bi-moon', 'bi-sun');
                toggleBtn.classList.replace('btn-outline-secondary', 'btn-outline-light');
                document.querySelector('.navbar').classList.replace('navbar-light', 'navbar-dark');
            }
        });
    </script>

    <div class="container flex-grow-1">