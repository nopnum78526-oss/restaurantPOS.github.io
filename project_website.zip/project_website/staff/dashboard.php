<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkStaff();

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    // Update order status
    $conn->query("UPDATE orders SET status = '$status' WHERE order_id = '$order_id'");

    // If completed, mark as paid and free table
    if ($status == 'completed') {
        $conn->query("UPDATE orders SET payment_status = 'paid' WHERE order_id = '$order_id'");

        $res = $conn->query("SELECT table_id FROM orders WHERE order_id = '$order_id'");
        if ($row = $res->fetch_assoc()) {
            $tid = $row['table_id'];
            $conn->query("UPDATE tables SET status = 'available' WHERE table_id = '$tid'");
        }
    } elseif ($status == 'cancelled') {
        // If cancelled, just free table
        $res = $conn->query("SELECT table_id FROM orders WHERE order_id = '$order_id'");
        if ($row = $res->fetch_assoc()) {
            $tid = $row['table_id'];
            $conn->query("UPDATE tables SET status = 'available' WHERE table_id = '$tid'");
        }
    }
}

// Fetch Active Orders (not completed or cancelled)
$orders = $conn->query("
    SELECT o.*, t.table_name, u.name as customer_name 
    FROM orders o 
    LEFT JOIN tables t ON o.table_id = t.table_id 
    LEFT JOIN users u ON o.user_id = u.id
    WHERE o.status NOT IN ('completed', 'cancelled')
    ORDER BY o.order_time ASC
");
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Kitchen / Staff Dashboard</h2>

<div class="row">
    <?php while ($order = $orders->fetch_assoc()): ?>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-<?php
                                                if ($order['status'] == 'pending') echo 'warning';
                                                elseif ($order['status'] == 'cooking') echo 'info';
                                                elseif ($order['status'] == 'served') echo 'primary';
                                                ?>">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Table: <?php echo $order['table_name']; ?></strong>
                    <span class="badge bg-secondary">#<?php echo $order['order_id']; ?></span>
                </div>
                <div class="card-body">
                    <p class="mb-1"><strong>Customer:</strong> <?php echo $order['customer_name']; ?></p>
                    <p class="mb-1"><strong>Payment:</strong>
                        <span class="badge bg-light text-dark border"><?php echo strtoupper($order['payment_method']); ?></span>
                        <span class="badge <?php echo $order['payment_status'] == 'paid' ? 'bg-success' : 'bg-danger'; ?>">
                            <?php echo ucfirst($order['payment_status']); ?>
                        </span>
                    </p>
                    <p class="mb-2 text-muted small"><?php echo $order['order_time']; ?></p>

                    <ul class="list-group list-group-flush mb-3">
                        <?php
                        $oid = $order['order_id'];
                        $items = $conn->query("
                        SELECT oi.*, m.name 
                        FROM order_items oi 
                        JOIN menu m ON oi.menu_id = m.menu_id 
                        WHERE oi.order_id = '$oid'
                    ");
                        while ($item = $items->fetch_assoc()):
                        ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo $item['name']; ?>
                                <span class="badge bg-dark rounded-pill"><?php echo $item['qty']; ?></span>
                            </li>
                        <?php endwhile; ?>
                    </ul>

                    <form method="POST">
                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                        <div class="input-group">
                            <select name="status" class="form-select">
                                <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="cooking" <?php echo $order['status'] == 'cooking' ? 'selected' : ''; ?>>Cooking</option>
                                <option value="served" <?php echo $order['status'] == 'served' ? 'selected' : ''; ?>>Served</option>
                                <option value="completed">Completed (Paid)</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                            <button type="submit" name="update_status" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php if ($orders->num_rows == 0): ?>
    <div class="alert alert-info text-center">No active orders at the moment.</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>