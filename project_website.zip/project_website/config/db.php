<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$dbname = 'restaurant_db';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for Thai language support
$conn->set_charset("utf8mb4");

// Set Timezone to Thailand
date_default_timezone_set('Asia/Bangkok');
