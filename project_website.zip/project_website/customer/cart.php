<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkLogin();

// Handle Remove from Cart
if (isset($_GET['remove'])) {
    $id = $_GET['remove'];
    unset($_SESSION['cart'][$id]);
    header("Location: cart.php");
    exit();
}

// Handle Checkout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['checkout'])) {
    if (empty($_SESSION['cart'])) {
        $error = "Cart is empty!";
    } else {
        $user_id = $_SESSION['user_id'];
        $table_id = $_POST['table_id'];
        $payment_method = $_POST['payment_method']; // Get payment method
        $total_price = 0;

        // Calculate total
        foreach ($_SESSION['cart'] as $menu_id => $qty) {
            $res = $conn->query("SELECT price FROM menu WHERE menu_id = '$menu_id'");
            $row = $res->fetch_assoc();
            $total_price += $row['price'] * $qty;
        }

        // Create Order with Payment Method
        $sql = "INSERT INTO orders (user_id, table_id, total_price, status, payment_method, payment_status) 
                VALUES ('$user_id', '$table_id', '$total_price', 'pending', '$payment_method', 'pending')";

        if ($conn->query($sql)) {
            $order_id = $conn->insert_id;

            // Create Order Items
            foreach ($_SESSION['cart'] as $menu_id => $qty) {
                $res = $conn->query("SELECT price FROM menu WHERE menu_id = '$menu_id'");
                $row = $res->fetch_assoc();
                $price = $row['price'];

                $conn->query("INSERT INTO order_items (order_id, menu_id, qty, price) VALUES ('$order_id', '$menu_id', '$qty', '$price')");
            }

            // Clear Cart
            unset($_SESSION['cart']);

            // Update Table Status
            $conn->query("UPDATE tables SET status = 'occupied' WHERE table_id = '$table_id'");

            header("Location: orders.php?success=1");
            exit();
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

$tables = $conn->query("SELECT * FROM tables WHERE status = 'available'");
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Your Cart</h2>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if (empty($_SESSION['cart'])): ?>
    <div class="alert alert-info">Your cart is empty. <a href="index.php">Go to Menu</a></div>
<?php else: ?>
    <div class="row">
        <div class="col-md-8">
            <table class="table table-bordered bg-white">
                <thead>
                    <tr>
                        <th>Menu</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $grand_total = 0;
                    foreach ($_SESSION['cart'] as $menu_id => $qty):
                        $res = $conn->query("SELECT * FROM menu WHERE menu_id = '$menu_id'");
                        $item = $res->fetch_assoc();
                        $total = $item['price'] * $qty;
                        $grand_total += $total;
                    ?>
                        <tr>
                            <td><?php echo $item['name']; ?></td>
                            <td>฿<?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo $qty; ?></td>
                            <td>฿<?php echo number_format($total, 2); ?></td>
                            <td>
                                <a href="cart.php?remove=<?php echo $menu_id; ?>" class="btn btn-sm btn-danger">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3" class="text-end fw-bold">Grand Total</td>
                        <td colspan="2" class="fw-bold">฿<?php echo number_format($grand_total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Checkout</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Select Table</label>
                            <select name="table_id" class="form-select" required>
                                <option value="">-- Select Table --</option>
                                <?php while ($t = $tables->fetch_assoc()): ?>
                                    <option value="<?php echo $t['table_id']; ?>"><?php echo $t['table_name']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" value="cash" checked>
                                <label class="form-check-label">Cash</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" value="qr">
                                <label class="form-check-label">QR Code (Scan)</label>
                            </div>
                        </div>
                        <button type="submit" name="checkout" class="btn btn-success w-100">Confirm Order</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>