<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$orders = $conn->query("
    SELECT o.*, t.table_name 
    FROM orders o 
    LEFT JOIN tables t ON o.table_id = t.table_id 
    WHERE o.user_id = '$user_id' 
    ORDER BY o.order_time DESC
");
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">My Orders</h2>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">Order placed successfully!</div>
<?php endif; ?>

<div class="table-responsive">
    <table class="table table-bordered bg-white">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Table</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Estimated Time</th> <!-- New Column -->
                <th>Date</th>
                <th>Items</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <tr data-order-id="<?php echo $order['order_id']; ?>" data-order-time="<?php echo strtotime($order['order_time']); ?>">
                    <td>#<?php echo $order['order_id']; ?></td>
                    <td><?php echo $order['table_name']; ?></td>
                    <td>฿<?php echo number_format($order['total_price'], 2); ?></td>
                    <td>
                        <span class="badge status-badge 
                        <?php
                        if ($order['status'] == 'pending') echo 'bg-warning';
                        elseif ($order['status'] == 'cooking') echo 'bg-info';
                        elseif ($order['status'] == 'served') echo 'bg-primary';
                        elseif ($order['status'] == 'completed') echo 'bg-success';
                        else echo 'bg-danger';
                        ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                    </td>
                    <td class="timer-cell font-monospace text-danger fw-bold">
                        <!-- Timer will be injected here by JS -->
                        -
                    </td>
                    <td><?php echo $order['order_time']; ?></td>
                    <td>
                        <ul class="list-unstyled mb-0">
                            <?php
                            $oid = $order['order_id'];
                            $items = $conn->query("
                            SELECT oi.*, m.name 
                            FROM order_items oi 
                            JOIN menu m ON oi.menu_id = m.menu_id 
                            WHERE oi.order_id = '$oid'
                        ");
                            while ($item = $items->fetch_assoc()):
                            ?>
                                <li><?php echo $item['name']; ?> x <?php echo $item['qty']; ?></li>
                            <?php endwhile; ?>
                        </ul>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
    function updateTimers() {
        const rows = document.querySelectorAll('tr[data-order-id]');
        const now = Math.floor(Date.now() / 1000); // Current timestamp in seconds

        rows.forEach(row => {
            const orderTime = parseInt(row.getAttribute('data-order-time'));
            const statusBadge = row.querySelector('.status-badge');
            const timerCell = row.querySelector('.timer-cell');
            const status = statusBadge.textContent.trim().toLowerCase();

            const elapsed = now - orderTime;
            let message = "";

            if (status === 'completed' || status === 'cancelled') {
                message = "Done";
                timerCell.classList.remove('text-danger');
                timerCell.classList.add('text-success');
            } else {
                // Logic: 10s -> Delivery, 15s -> Table Free
                const deliveryTime = 10;
                const clearTime = 15;

                if (elapsed < deliveryTime) {
                    message = `Delivery in ${deliveryTime - elapsed}s`;
                } else if (elapsed < clearTime) {
                    message = `Served. Table free in ${clearTime - elapsed}s`;
                } else {
                    message = "Clearing table...";
                }
            }
            timerCell.textContent = message;
        });
    }

    function syncStatus() {
        fetch('/api/auto_update.php')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success' && data.updates.length > 0) {
                    // If there are updates, reload to reflect status changes cleanly
                    location.reload();
                }
            })
            .catch(err => console.error('Error syncing status:', err));
    }

    // Update timers every second
    setInterval(updateTimers, 1000);
    updateTimers(); // Initial call

    // Sync with server every 1 second to check for status updates
    setInterval(syncStatus, 1000);
</script>

<?php include '../includes/footer.php'; ?>