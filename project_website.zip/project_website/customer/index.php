<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
checkLogin();

// Fetch all menu items
$result = $conn->query("SELECT * FROM menu WHERE status = 1");
$menu_items = [];
while ($row = $result->fetch_assoc()) {
    $menu_items[] = $row;
}

// Get unique categories
$categories = array_unique(array_column($menu_items, 'category'));
sort($categories);
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4 text-center">Our Menu</h2>

<!-- Category Filter -->
<ul class="nav nav-pills justify-content-center mb-4" id="pills-tab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab">All</button>
    </li>
    <?php foreach ($categories as $cat): ?>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-<?php echo strtolower(str_replace(' ', '-', $cat)); ?>-tab" data-bs-toggle="pill" data-bs-target="#pills-<?php echo strtolower(str_replace(' ', '-', $cat)); ?>" type="button" role="tab"><?php echo $cat; ?></button>
        </li>
    <?php endforeach; ?>
</ul>

<div class="tab-content" id="pills-tabContent">
    <!-- All Items -->
    <div class="tab-pane fade show active" id="pills-all" role="tabpanel">
        <div class="row">
            <?php foreach ($menu_items as $item): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <?php
                        $img_src = $item['image'];
                        if ($img_src && !filter_var($img_src, FILTER_VALIDATE_URL)) {
                            $img_src = '../uploads/' . $img_src;
                        }
                        ?>
                        <?php if ($img_src): ?>
                            <img src="<?php echo $img_src; ?>" class="card-img-top" alt="<?php echo $item['name']; ?>" style="height: 200px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 200px;">No Image</div>
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo $item['name']; ?></h5>
                            <p class="card-text text-muted small"><?php echo $item['description']; ?></p>
                            <div class="mt-auto d-flex justify-content-between align-items-center">
                                <span class="h5 mb-0 text-primary">฿<?php echo number_format($item['price'], 2); ?></span>
                                <form method="POST" action="add_to_cart.php">
                                    <input type="hidden" name="menu_id" value="<?php echo $item['menu_id']; ?>">
                                    <button type="submit" class="btn btn-outline-primary btn-sm"><i class="bi bi-cart-plus"></i> Add</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Category Tabs -->
    <?php foreach ($categories as $cat): ?>
        <div class="tab-pane fade" id="pills-<?php echo strtolower(str_replace(' ', '-', $cat)); ?>" role="tabpanel">
            <div class="row">
                <?php
                $cat_items = array_filter($menu_items, function ($item) use ($cat) {
                    return $item['category'] == $cat;
                });
                foreach ($cat_items as $item):
                ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <?php
                            $img_src = $item['image'];
                            if ($img_src && !filter_var($img_src, FILTER_VALIDATE_URL)) {
                                $img_src = '../uploads/' . $img_src;
                            }
                            ?>
                            <?php if ($img_src): ?>
                                <img src="<?php echo $img_src; ?>" class="card-img-top" alt="<?php echo $item['name']; ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 200px;">No Image</div>
                            <?php endif; ?>
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo $item['name']; ?></h5>
                                <p class="card-text text-muted small"><?php echo $item['description']; ?></p>
                                <div class="mt-auto d-flex justify-content-between align-items-center">
                                    <span class="h5 mb-0 text-primary">฿<?php echo number_format($item['price'], 2); ?></span>
                                    <form method="POST" action="add_to_cart.php">
                                        <input type="hidden" name="menu_id" value="<?php echo $item['menu_id']; ?>">
                                        <button type="submit" class="btn btn-outline-primary btn-sm"><i class="bi bi-cart-plus"></i> Add</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php include '../includes/footer.php'; ?>