<?php
require_once '../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];
$current_time = time();
$updates = [];

// Fetch active orders for the user
$sql = "SELECT order_id, table_id, status, order_time FROM orders WHERE user_id = '$user_id' AND status != 'completed' AND status != 'cancelled'";
$result = $conn->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $order_id = $row['order_id'];
        $table_id = $row['table_id'];
        $order_timestamp = strtotime($row['order_time']);
        $time_diff = $current_time - $order_timestamp;
        $new_status = $row['status'];
        $changed = false;

        // Logic: 10s -> Served, 15s -> Completed & Free Table
        if ($time_diff >= 15) {
            if ($row['status'] != 'completed') {
                $new_status = 'completed';
                // Mark as paid and free table
                $conn->query("UPDATE orders SET status = 'completed', payment_status = 'paid' WHERE order_id = '$order_id'");
                $conn->query("UPDATE tables SET status = 'available' WHERE table_id = '$table_id'");
                $changed = true;
            }
        } elseif ($time_diff >= 10) {
            if ($row['status'] == 'pending' || $row['status'] == 'cooking') {
                $new_status = 'served';
                $conn->query("UPDATE orders SET status = 'served' WHERE order_id = '$order_id'");
                $changed = true;
            }
        }

        if ($changed) {
            $updates[] = [
                'order_id' => $order_id,
                'status' => $new_status,
                'time_diff' => $time_diff
            ];
        }
    }
}

echo json_encode(['status' => 'success', 'updates' => $updates]);
